<!-- session_start();
session_destroy();
header('Location: login.php');
exit; -->
<?php
session_start();
if (session_destroy()) {
header("Location: about.html");
}
?>